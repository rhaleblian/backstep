optimize="-O1"
d_setregid='undef'
d_setreuid='undef'
