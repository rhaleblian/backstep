#undef __STDC__
#include <sys/types.h>
#define __STDC__ 1
