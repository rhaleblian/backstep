/* Configuration for GCC for ARM running NetBSD as host.  */

#ifndef SYS_SIGLIST_DECLARED
#define SYS_SIGLIST_DECLARED
#endif
