main(a){printf(a,34,a="main(a){printf(a,34,a=%c%s%c,34);}",34);}
