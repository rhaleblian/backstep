/* intl.c - internationalization */

#include "gansidecl.h"
#include "intl.h"

const char localedir[] = LOCALEDIR;
